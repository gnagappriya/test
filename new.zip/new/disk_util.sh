#!/bin/ksh
HOST='10.230.189.138'
USER='copasg'
PASSWD='test1234'
DATE=`date '+%d-%m-%Y'`

FILE_NAME1=rds050a021_mpdserver1_rdwsmpd01_WS-MPD97_DISK
FILE_PATH=/wls_domains/rdwsmpd01/SCRIPTS/DISK
UPLOAD_PATH=/export/home/situser/copasg_area/COPReports/DISK/WS/MPD


ftp -n $HOST <<END_SCRIPT
quote USER $USER
quote PASS $PASSWD
cd ${UPLOAD_PATH}
lcd ${FILE_PATH}
prompt off
put ${FILE_NAME1}_${DATE}.csv
quit
prompt on
END_SCRIPT

cd $FILE_PATH
rm ${FILE_NAME1}_${DATE}.csv
