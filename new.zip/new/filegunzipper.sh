#!/bin/sh

#set -x
CD=/usr/bin/cd
LS=/usr/bin/ls
GREP=/usr/bin/grep
AWK=/usr/bin/awk
CAT=/usr/bin/cat
TAR=/usr/bin/tar
RM=/usr/bin/rm
GZIP=/usr/bin/gzip
FOLDERLIST=/wls_domains/rdwsmpd01/SCRIPTS/filegunzipperpaths
TEMPFILE=/tmp/asgfile.txt

for FOLDER_PATH in `${CAT} ${FOLDERLIST}`; do

if test -d ${FOLDER_PATH}; then

cd $FOLDER_PATH

 $LS -lrt | $GREP -i "^d" | $AWK -F" " '{print $9}'> ${TEMPFILE}
  for i in `$CAT ${TEMPFILE}`;
    do
      $TAR -cf $i.tar $i
      $GZIP -f $i.tar
      $RM -r $i
    done
 find . -name "*.tar" -exec gzip {} \;
else
continue;
fi

done
