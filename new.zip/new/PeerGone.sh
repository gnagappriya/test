grep -i 'PeerGoneException' /wls_domains/rdwsmpd01/logs/bea/mpdserver1_rdwsmpd01.log >> /wls_domains/rdwsmpd01/SCRIPTS/peergoneexception
cat /wls_domains/rdwsmpd01/SCRIPTS/peergoneexception |mailx -s mpdserver1_rdwsmpd01 nagapriya.govindarajulu@bt.com 
> /wls_domains/rdwsmpd01/SCRIPTS/peergoneexception

