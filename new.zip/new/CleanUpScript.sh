#!/usr/bin/bash

TimeVar="+20"


# The below 3 has to be enabled after Jan 1 2011.


#/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/07_Outgoing
#/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/08_Outgoing
#/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/10_Outgoing


DIRList="/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/01_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/02_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/03_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/04_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/05_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/KillSessionRequestChannel_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/KSResponseChannel_Incoming
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/MNSDResponseChannel_Incoming
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/MQRequestChannel_Incoming
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages2/01_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages2/02_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages2/03_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages2/04_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages2/05_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages2/KillSessionRequestChannel_Outgoing
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages2/KSResponseChannel_Incoming
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages2/MNSDResponseChannel_Incoming
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages2/MQRequestChannel_Incoming"

for val in $DIRList
do
	find $val -mtime $TimeVar -print >>outFile
	find $val -mtime $TimeVar -exec rm -rf {} \;
done


## 5 days for mpd1 and mpd2 log files.

DIRList="/wls_domains/rdwsmpd01/logs/project/zipbackup/messages1/mpd1_logs
/wls_domains/rdwsmpd01/logs/project/zipbackup/messages2/mpd2_logs"


TimeVar="+5"

for val in $DIRList
do
	find $val -mtime $TimeVar -print >>outFile
	find $val -mtime $TimeVar -exec rm -rf {} \;
done
