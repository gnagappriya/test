#!/bin/sh
set -x

DIR1=/wls_domains/rdwsmpd01_logs/project/backup/mpd1_log
DIR2=/wls_domains/rdwsmpd01_logs/project/backup/mpd2_log


cd ${DIR1}

PREV_1STHOUR=`TZ=BST+ date +%Y%m%d%H`

ls -lrt |awk -F" " '{print $9}' > /tmp/3rdhr

grep ${PREV_1STHOUR} /tmp/3rdhr  > /tmp/4thhr

for files in `cat /tmp/4thhr`
do

cd ${files}
gzip *

cd ${DIR1}
done

cd ${DIR2}

PREV_1STHOUR=`TZ=BST+ date +%Y%m%d%H`

ls -lrt |awk -F" " '{print $9}' > /tmp/3rdhr

grep ${PREV_1STHOUR} /tmp/3rdhr  > /tmp/4thhr

for files in `cat /tmp/4thhr`
do

cd ${files}
gzip *

cd ${DIR2}
done
