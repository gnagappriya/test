clear
var=`date '+%d'"-"'%m'"-"'%Y'`
if [ $var -eq '21-11-2009' ]
then
        echo success
else
        echo fail
fi
