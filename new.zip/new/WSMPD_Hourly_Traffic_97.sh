#!/usr/bin/ksh

DATE=`date '+%d-%m-%Y'`
Hour=`date '+%H'`
#Hour=$1
SHIFTDATE=/wls_domains/rdwsmpd01/SCRIPTS/new/shiftdate.sh
Day=`date '+%d'`
TIME=`date '+%d-%m-%y'`


## If Hour =0 then we have to take previous day 23 Hour Transaction...
if [ $Hour -eq 0 ]; then
	echo "Hour 0";
	Hour=23
	DAY=`date '+%d'`
	MONTH=`date '+%m'`
	YEAR=`date '+%Y'`
	Day=`$SHIFTDATE $YEAR$MONTH$DAY -1|cut -c7-8`
	YEAR=`$SHIFTDATE $YEAR$MONTH$DAY -1|cut -c1-4`
	MONTH=`$SHIFTDATE $YEAR$MONTH$DAY -1|cut -c5-6`
	DATE="$Day-$MONTH-$YEAR"
else
	Hour=`expr $Hour - 1`
	if [ "$Hour" -eq 1 -o "$Hour" -eq 2 -o "$Hour" -eq 3 -o "$Hour" -eq 4 -o "$Hour" -eq 5 -o "$Hour" -eq 6  -o "$Hour" -eq 7 -o "$Hour" -eq 8 -o "$Hour" -eq 9 -o "$Hour" -eq 0 ]
	then
        	Var1="0"
        	Hour=$Var1$Hour
	fi
fi
DATAFILE=/wls_domains/rdwsmpd01/SCRIPTS/new/Hourly_Traffic_WS-MPD97_$DATE.dat


if [ "$Day" -eq "01" -o "$Day" -eq "02" -o "$Day" -eq "03" -o "$Day" -eq "04" -o "$Day" -eq "05" -o "$Day" -eq "06"  -o "$Day" -eq "07" -o "$Day" -eq "08" -o "$Day" -eq "09" ]
 then
        Day=`echo $Day|cut -c2`
fi

#echo "Day =$Day : Hour = $Hour"

Pattern="$Day $Hour:"

TIME="$TIME $Hour:00"


# PAL to MPD.

PALCount=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/MQRequestChannel_Incoming |grep "$Pattern" |wc -l`

MNSDResponse=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/MNSDResponseChannel_Incoming |grep "$Pattern" |wc -l`

MPD_ESBROBT=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/KillSessionRequestChannel_Outgoing |grep "$Pattern" |wc -l`
ESBROBT_MPD=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/KSResponseChannel_Incoming |grep "$Pattern" |wc -l`
MPD_MNSD_SA=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/MNSDSARequestChannel_Outgoing |grep "$Pattern" |wc -l`

PALOut01=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/01_Outgoing |grep "$Pattern" |wc -l`
PALOut02=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/02_Outgoing |grep "$Pattern" |wc -l`
PALOut03=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/03_Outgoing |grep "$Pattern" |wc -l`
PALOut04=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/04_Outgoing |grep "$Pattern" |wc -l`
PALOut05=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/05_Outgoing |grep "$Pattern" |wc -l`
PALOut07=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/07_Outgoing |grep "$Pattern" |wc -l`
PALOut08=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/08_Outgoing |grep "$Pattern" |wc -l`
PALOut10=`ls -tlr /wls_domains/rdwsmpd01/logs/project/messages1/10_Outgoing |grep "$Pattern" |wc -l`

PALOut=`expr $PALOut01 + $PALOut02 + $PALOut03 + $PALOut04 + $PALOut05 + $PALOut07 + $PALOut08 + $PALOut10`

if [ -f $DATAFILE ]; then
  echo $TIME,$PALCount,$MPD_MNSD_SA,$MNSDResponse,$MPD_ESBROBT,$ESBROBT_MPD,$PALOut >>$DATAFILE
else
 echo TIME,PAL_MPD,MPD_MNSD-SA,GTC_MPD,MPD_ESBROBT,ESBROBT_MPD,MPD_PAL>$DATAFILE
 echo $TIME,$PALCount,$MPD_MNSD_SA,$MNSDResponse,$MPD_ESBROBT,$ESBROBT_MPD,$PALOut >>$DATAFILE
fi

find /wls_domains/rdwsmpd01/SCRIPTS/new -name "Hourly_Traffic_WS-MPD97_*" -mtime +10 -exec rm -f {} \;
