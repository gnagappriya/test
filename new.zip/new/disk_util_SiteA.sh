
DATE=`date '+%d-%m-%y %H:%M:%S'`

# DISK Statistics..




#echo $DATE>>/wls_domains/rdwsmpd01/SCRIPTS/disk_util_SiteA.dat
DISK=`df -k|grep /wls_domains/rdwsmpd01_logs|awk '{print $5}'`
echo "$DATE /wls_domains/rdwsmpd01_logs $DISK" >>/wls_domains/rdwsmpd01/SCRIPTS/disk_util_SiteA.dat
DISK=`df -k|grep /wls_domains/rdwsmpd01|grep -v /wls_domains/rdwsmpd01_logs|awk '{print $5}'`
echo "$DATE /wls_domains/rdwsmpd01 $DISK" >>/wls_domains/rdwsmpd01/SCRIPTS/disk_util_SiteA.dat
DISK=`df -k|grep /mqlocal|awk '{print $5}'`
echo "$DATE /mqlocal $DISK" >>/wls_domains/rdwsmpd01/SCRIPTS/disk_util_SiteA.dat
#DISK=`df -k|grep /mqcl_RDS502P1|awk '{print $5}'`
#echo "/mqcl_RDS502P1 $DISK" >>/wls_domains/rdwsmpd01/SCRIPTS/disk_util_SiteA.dat
DISK=`df -k|grep /bptm_logs |awk '{print $5}'`
echo "$DATE /bptm_logs $DISK">> /wls_domains/rdwsmpd01/SCRIPTS/disk_util_SiteA.dat


#HOST='10.230.189.138'
#USER='copasg'
#PASSWD='test1234'

#ftp -n $HOST <<END_SCRIPT
#quote USER $USER
#quote PASS $PASSWD

#cd /export/home/situser/copasg_area/testbox/diskutil

#lcd /wls_domains/rdwsmpd01/SCRIPTS

#prompt off
#mput disk_util_SiteA.dat
#quit
#prompt on
#END_SCRIPT

