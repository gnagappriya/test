#/bin/sh
#set -x
. /wls_domains/rdwsmpd01/bt_utils_inc.sh

>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
echo >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
myperf mpdserver2_rdwsmpd01 jvm >> /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
sleep 5
grep -i 'OutOfMemoryError' /wls_domains/rdwsmpd01/logs/bea/mpdserver2_rdwsmpd01.log >> /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
echo "-----------------------------------------------------------------------------------">>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
echo >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022

cat /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022

rm /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
