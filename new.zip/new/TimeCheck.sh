echo "Date : $1"

cd /wls_domains/rdwsmpd01/logs/project/messages/RequestChannel_Incoming/$1
#echo a
echo "PAL to COP:" 
cat `grep $2 *.log | cut -d":" -f1` | grep "INFO [[ACTIVE]" | cut -d" " -f1,2
cd /wls_domains/rdwsmpd01/logs/project/messages/MNSDRequestChannel_Outgoing/$1
echo "COP to IMB:" 
grep "$2" *.log | grep "INFO [[ACTIVE]" | cut -d" " -f1,2 | cut -d":" -f2,3,4
cd /wls_domains/rdwsmpd01/logs/project/messages/MNSDResponseChannel_Incoming/$1
echo "IMB to COP:"
cat `grep $2 *.log | cut -d":" -f1` | grep "INFO [[ACTIVE]" | cut -d" " -f1,2
cd /wls_domains/rdwsmpd01/logs/project/messages/01_Outgoing/$1
echo "COP to PAL:" 
grep "$2" *.log | grep "INFO [[ACTIVE]" | cut -d" " -f1,2 | cut -d":" -f2,3,4 
