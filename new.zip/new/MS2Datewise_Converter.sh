#!/bin/ksh

SHIFTDATE=/wls_domains/rdwsmpd01/SCRIPTS/new/shiftdate.sh
DAY=`date '+%d'`
MONTH=`date '+%m'`
YEAR=`date '+%Y'`

YEAR1=`$SHIFTDATE $YEAR$MONTH$DAY -1|cut -c1-4`
MONTH1=`$SHIFTDATE $YEAR$MONTH$DAY -1|cut -c5-6`
DAY1=`$SHIFTDATE $YEAR$MONTH$DAY -1|cut -c7-8`
SearchDay=$DAY1
Pattern=""



val=$DAY1"-"$MONTH1"-"$YEAR1

if [ $MONTH1 -eq 01 ]; then
   MONTH="Jan"
elif [ $MONTH1 -eq 02 ]; then
	MONTH="Feb"
elif [ $MONTH1 -eq 03 ]; then
	MONTH="Mar"
elif [ $MONTH1 -eq 04 ]; then
	MONTH="Apr"
elif [ $MONTH1 -eq 05 ]; then
	MONTH="May"
elif [ $MONTH1 -eq 06 ]; then
	MONTH="Jun"
elif [ $MONTH1 -eq 07 ]; then
	MONTH="Jul"
elif [ $MONTH1 -eq 08 ]; then
	MONTH="Aug"
elif [ $MONTH1 -eq 09 ]; then
	MONTH="Sep"
elif [ $MONTH1 -eq 10 ]; then
	MONTH="Oct"
elif [ $MONTH1 -eq 11 ]; then
	MONTH="Nov"
elif [ $MONTH1 -eq 12 ]; then
	MONTH="Dec"
fi

if [ "$DAY1" -eq "01" -o "$DAY1" -eq "02" -o "$DAY1" -eq "03" -o "$DAY1" -eq "04" -o "$DAY1" -eq "05" -o "$DAY1" -eq "06"  -o "$DAY1" -eq "07" -o "$DAY1" -eq "08" -o "$DAY1" -eq "09" ]
 then
        SearchDay=`echo $DAY1|cut -c2`
	Pattern="$MONTH  $SearchDay"
else
	Pattern="$MONTH $DAY1"
fi

FileArchival()
{
	PATH=$1;
	COPYPATH="$PATH/$val"
	Counter=0
	CurrentDIR=`pwd`

	echo "Pattern = $Pattern : PATH=$PATH : Copy Path=$COPYPATH"
	cd $PATH

	/usr/bin/mkdir $COPYPATH
	FILES=`/usr/bin/ls -ltr *.log |/usr/bin/grep "$Pattern"`
	/usr/bin/echo "$FILES">/wls_domains/rdwsmpd01/SCRIPTS/BroFiles_MS2.dat


	/usr/bin/cat /wls_domains/rdwsmpd01/SCRIPTS/BroFiles_MS2.dat |while read line
 	do
        	if [ -z "$line" ]; then
                	echo "No files to Move on '$Hour' Hour"
                	break
        	fi
                FileName=`echo $line|/usr/bin/awk '{print $9}'`
                /usr/bin/mv $FileName  $COPYPATH
                echo "MOVE =>$FileName  $COPYPATH"
                Counter=`/usr/bin/expr $Counter + 1`
 	done
	echo "No of files Moved on '$Pattern' = $Counter"
	cd $CurrentDIR
	
}

MoveMNSDDirectory()
{
  HourUS="_Hour"
  Count=0
  MovePath="$1/$val/."
  while [ $Count -le 22 ]; do
  	PATH1=$1
	Hour=""
	if [ $Count -ge 0 -a $Count -le 9 ]; then
		Hour="0"
		Hour="$Hour$Count"
	else
		Hour=$Count
	fi
	PATH1="$PATH1/$Hour$HourUS"
	/usr/bin/mv $PATH1 $MovePath
	Count=`/usr/bin/expr $Count + 1`
	echo "mv $PATH1 $MovePath"
  done
	
}

## MS2 Daily Split......

FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/MQRequestChannel_Incoming"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/MNSDResponseChannel_Incoming"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/01_Outgoing"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/02_Outgoing"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/03_Outgoing"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/04_Outgoing"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/05_Outgoing"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/07_Outgoing"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/08_Outgoing"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/10_Outgoing"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/KSResponseChannel_Incoming"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/MNSDSARequestChannel_Outgoing"
FileArchival "/wls_domains/rdwsmpd01/logs/project/messages2/KillSessionRequestChannel_Outgoing"
MoveMNSDDirectory "/wls_domains/rdwsmpd01/logs/project/messages2/MNSDResponseChannel_Incoming"

