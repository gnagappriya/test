#!/usr/bin/bash

#PRE RELEASE BACKUP SCRIPT FOR WHOLESALE MPD

if [ $# -lt 1 ]
then
        echo " USAGE :"
        echo "~~~~~~~~~~"
        echo "./Releasebackup.sh <PRE_RELEASE_VERSION>"
        echo "<PRE_RELEASE_VERSION> -- This directory will be created within the backup directory"
        echo "Example : If <PRE_RELEASE_VERSION> is 1.0.1 then,"
        echo "the directory created within backup will be MPD_Release_1.0.1-<DATE>"
        exit 1
fi

echo `date`
echo "~~~~~~~~~~~~~~~~~~~"
DATE=`date '+%d-%m-%Y'`

DOMAIN_HOME=/wls_domains/rdwsmpd01
INSTALL_HOME=/app/ws/mpd/mpd_rel
PRE_RELEASE_VERSION=$1
#CURRENT_VERSION=$2
BACKUP_DIR=/wls_domains/rdwsmpd01_logs/backup/MPD_Release_$PRE_RELEASE_VERSION-$DATE

## Confirmation
echo
echo "Following are the details provided : "
echo "DOMAIN_HOME : " $DOMAIN_HOME
echo "INSTALL_HOME : " $INSTALL_HOME
echo "PRE_RELEASE_VERSION : "  $PRE_RELEASE_VERSION
echo "BACKUP_DIR : " $BACKUP_DIR
echo
echo "Do you want to proceed ?(y|Y/n|N) : "
read RESPONSE
#echo $RESPONSE

if [ $RESPONSE == "n" -o $RESPONSE == "N" ]
then
        exit 2
fi

echo
echo "STATUS :"
echo "~~~~~~~"

mkdir $BACKUP_DIR
if [ $? -eq 0 ]
then
        echo "Creating $BACKUP_DIR : SUCCESS "
else
        echo "Creating $BACKUP_DIR : FAILURE "
        exit 3
fi

#Backup of all the application folders:

cp -r $INSTALL_HOME/  $BACKUP_DIR/mpd_Release_$PRE_RELEASE_VERSION
if [ $? -eq 0 ]
then
        echo "Copying $INSTALL_HOME/mpd_Release_$PRE_RELEASE_VERSION : SUCCESS "
else
        echo "Copying $INSTALL_HOME/mpd_Release_$PRE_RELEASE_VERSION : FAILURE "
fi


#Backup of all the admin and managed servers [This will include the backup of the ldap and stage directories as well.] and any custom security providers.

cp -r  $DOMAIN_HOME/config  $BACKUP_DIR/config_$PRE_RELEASE_VERSION
if [ $? -eq 0 ]
then
        echo "Archiving $DOMAIN_HOME/config : SUCCESS "
else
        echo "Archiving $DOMAIN_HOME/config : FAILURE "
fi


#cp -r  $DOMAIN_HOME/keystores  $BACKUP_DIR/keystores_$PRE_RELEASE_VERSION
#
#if [ $? -eq 0 ]
#then
#        echo "Archiving $DOMAIN_HOME/keystores : SUCCESS "
#else
#        echo "Archiving $DOMAIN_HOME/keystores : FAILURE "
#fi

cp -r  $DOMAIN_HOME/user_staged_config  $BACKUP_DIR/user_staged_config_$PRE_RELEASE_VERSION
if [ $? -eq 0 ]
then
        echo "Archiving $DOMAIN_HOME/user_staged_config : SUCCESS "
else
        echo "Archiving $DOMAIN_HOME/user_staged_config : FAILURE "
fi

cp  -r $DOMAIN_HOME/*.sh $DOMAIN_HOME/bin $BACKUP_DIR
if [ $? -eq 0 ]
then
        echo "Copying .sh files : SUCCESS "
else
        echo "Copying .sh files : FAILURE "
fi

cp -r  $DOMAIN_HOME/security  $BACKUP_DIR/security_$PRE_RELEASE_VERSION
if [ $? -eq 0 ]
then
        echo "Archiving $DOMAIN_HOME/security : SUCCESS "
else
        echo "Archiving $DOMAIN_HOME/security : FAILURE "
fi

echo
echo
echo "BACKUP COMPLETE !!!!"
