#/bin/sh
#set -x
. /wls_domains/rdwsmpd01/bt_utils_inc.sh
myperf mpdserver1_rdwsmpd01 jvm >> /wls_domains/rdwsmpd01/SCRIPTS/htest1 
sleep 5
grep -i 'OutOfMemoryError' /wls_domains/rdwsmpd01/logs/bea/mpdserver1_rdwsmpd01.log >> /wls_domains/rdwsmpd01/SCRIPTS/htest1
cat /wls_domains/rdwsmpd01/SCRIPTS/htest1 |mailx -s mpdserver1_rdwsmpd01 hclcopasg@bt.com 
> /wls_domains/rdwsmpd01/SCRIPTS/htest1
