#!/bin/sh
#set -x

find /wls_domains/rdwsmpd01/servers/mpdserver?_rdwsmpd01/data/store/diagnostics -type f -name "*.DAT" >/tmp/tempfile_flush

for i in `cat /tmp/tempfile_flush`;do
#f=`echo $i |awk -F"/" '{print $2}'`
cat /dev/null >$i

done
