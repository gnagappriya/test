#!/bin/ksh

find /wls_domains/rdwsmpd01_logs/project/messages/SVRCONN_Outgoing/$d -name \*.log -mtime -10 -exec mv {} /wls_domains/rdwsmpd01_logs/project/messages/backup/SVRCONN_Outgoing/$d \;

cd /wls_domains/rdwsmpd01_logs/project/messages/backup/SVRCONN_Outgoing/$d/

zip -jvm `date '+%Y%m%d%H%M%S'`.zip *.log

find /wls_domains/rdwsmpd01_logs/project/messages/RequestChannel_Incoming/$d -name \*.log -mtime -10 -exec mv {} /wls_domains/rdwsmpd01_logs/project/messages/backup/RequestChannel_Incoming/$d \;

cd /wls_domains/rdwsmpd01_logs/project/messages/backup/RequestChannel_Incoming/$d

zip -jvm `date '+%Y%m%d%H%M%S'`.zip *.log

find /wls_domains/rdwsmpd01_logs/project/messages/CCMRequestChannel_Incoming/$d -name \*.log -mtime -10 -exec mv {} /wls_domains/rdwsmpd01_logs/project/messages/backup/CCMRequestChannel_Incoming/$d \;

cd /wls_domains/rdwsmpd01_logs/project/messages/backup/CCMRequestChannel_Incoming/$d

zip -jvm `date '+%Y%m%d%H%M%S'`.zip *.log


find /wls_domains/rdwsmpd01_logs/project/messages/MNSDRequestChannel_Outgoing/$d -name \*.log -mtime -10 -exec mv {} /wls_domains/rdwsmpd01_logs/project/messages/backup/MNSDRequestChannel_Outgoing/$d \;

cd /wls_domains/rdwsmpd01_logs/project/messages/backup/MNSDRequestChannel_Outgoing/$d

zip -jvm `date '+%Y%m%d%H%M%S'`.zip *.log


find /wls_domains/rdwsmpd01_logs/project/messages/MNSDResponseChannel_Incoming/$d -name \*.log -mtime -10 -exec mv {} /wls_domains/rdwsmpd01_logs/project/messages/backup/MNSDResponseChannel_Incoming/$d \;

cd /wls_domains/rdwsmpd01_logs/project/messages/backup/MNSDResponseChannel_Incoming/$d

zip -jvm `date '+%Y%m%d%H%M%S'`.zip *.log


find /wls_domains/rdwsmpd01_logs/project/mpd.log.\* -mtime +10 -type f -exec mv {} /wls_domains/rdwsmpd01_logs/project/backup \;

cd /wls_domains/rdwsmpd01_logs/project/backup/

zip -jvm `date '+%Y%m%d%H%M%S'`.zip *.log.*
