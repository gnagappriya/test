#!/usr/bin/ksh

PATH=$PATH:/opt/bea/mps/btwlutils/1_4/bin
export PATH

PATH=$PATH:/usr/sbin
export PATH
#FILE_DATE ENABLES CREATION OF FILE DATE-VISE...
file_date=`date '+%d-%m-%Y`

SYSDT=`date '+%d-%m-%Y %T'`

echo "$SYSDT \n\n" >> /wls_domains/rdwsmpd01/SCRIPTS/closewait.txt 
echo "COUNT FOR NO OF CONNECTIONS  WITH CLOSE_WAIT() STATE" >> /wls_domains/rdwsmpd01/SCRIPTS/closewait.txt
netstat | grep -i "61000" | grep -i "CLOSE_WAIT" | wc -l >> /wls_domains/rdwsmpd01/SCRIPTS/closewait.txt
echo "---------------------------------------------------" >> /wls_domains/rdwsmpd01/SCRIPTS/closewait.txt 


