#!/bin/sh
#set -x

DIR=/wls_domains/rdwsmpd01_logs/project/backup/mpd2_log

cd ${DIR}
PREV_11THHOUR=`TZ=BST+10 date +%Y%m%d%H`
PREV_10THHOUR=`TZ=BST+9 date +%Y%m%d%H`
PREV_9THHOUR=`TZ=BST+8 date +%Y%m%d%H`
PREV_8THHOUR=`TZ=BST+7 date +%Y%m%d%H`
PREV_7THHOUR=`TZ=BST+6 date +%Y%m%d%H`
PREV_6THHOUR=`TZ=BST+5 date +%Y%m%d%H`
PREV_5THHOUR=`TZ=BST+4 date +%Y%m%d%H`
PREV_4THHOUR=`TZ=BST+3 date +%Y%m%d%H`
PREV_3RDHOUR=`TZ=BST+2 date +%Y%m%d%H`
PREV_2NDHOUR=`TZ=BST+1 date +%Y%m%d%H`
PREV_1STHOUR=`TZ=BST+ date +%Y%m%d%H`

ls -lrt |awk -F" " '{print $9}' > /tmp/Allhr

grep ${PREV_11THHOUR} /tmp/Allhr  > /tmp/Tothr
grep ${PREV_10THHOUR} /tmp/Allhr >> /tmp/Tothr
grep ${PREV_9THHOUR} /tmp/Allhr  >> /tmp/Tothr
grep ${PREV_8THHOUR} /tmp/Allhr  >> /tmp/Tothr
grep ${PREV_8THHOUR} /tmp/Allhr  >> /tmp/Tothr
grep ${PREV_7THHOUR} /tmp/Allhr  >> /tmp/Tothr
grep ${PREV_6THHOUR} /tmp/Allhr  >> /tmp/Tothr
grep ${PREV_5THHOUR} /tmp/Allhr  >> /tmp/Tothr
grep ${PREV_4THHOUR} /tmp/Allhr  >> /tmp/Tothr
grep ${PREV_3RDHOUR} /tmp/Allhr  >> /tmp/Tothr
grep ${PREV_2NDHOUR} /tmp/Allhr  >> /tmp/Tothr
grep ${PREV_1STHOUR} /tmp/Allhr  >> /tmp/Tothr

for files in `cat /tmp/Tothr`
do

cd ${files}
gzip *
cd ${DIR}
#tar -cf ${files}.tar ${files}
#gzip ${files}.tar
#rm -rf ${files}

done

