clear
var=`date '+%d'"-"'%m'"-"'%Y'`
echo Kill session count
