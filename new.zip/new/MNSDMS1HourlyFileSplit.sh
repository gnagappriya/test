#!/bin/ksh

DirName=/wls_domains/rdwsmpd01/logs/project/messages1/MNSDResponseChannel_Incoming

DATE=`date '+%d-%m-%Y'`
Hour=`date '+%H'`
#Hour=$1
Day=`date '+%d'`

Hour=`expr $Hour - 1`
if [ "$Hour" -eq 1 -o "$Hour" -eq 2 -o "$Hour" -eq 3 -o "$Hour" -eq 4 -o "$Hour" -eq 5 -o "$Hour" -eq 6  -o "$Hour" -eq 7 -o "$Hour" -eq 8 -o "$Hour" -eq 9 -o "$Hour" -eq 0 ]
then
	Var1="0"
	Hour=$Var1$Hour
fi

if [ "$Day" -eq "01" -o "$Day" -eq "02" -o "$Day" -eq "03" -o "$Day" -eq "04" -o "$Day" -eq "05" -o "$Day" -eq "06"  -o "$Day" -eq "07" -o "$Day" -eq "08" -o "$Day" -eq "09" ]
then
        Day=`echo $Day|cut -c2`
fi

HourUS="_Hour/"
SLASH="/"

HourName=$SLASH$Hour$HourUS
#HourName=$Hour$HourUS


#DirName=$DirName$DATE
COPYPATH=$DirName$HourName

echo "Copy PAth = $COPYPATH: Hour =$Hour"
mkdir $COPYPATH

LOGFILES="/*.log"
LOGFILES=$DirName$LOGFILES

Pattern="$Day $Hour"
echo "Pattern = $Pattern"
FILES=`ls -ltr $LOGFILES |grep "$Pattern"`
echo "$FILES" >/wls_domains/rdwsmpd01/SCRIPTS/MNSDMS1.dat

Counter=0
cat /wls_domains/rdwsmpd01/SCRIPTS/MNSDMS1.dat |while read line
 do
	if [ -z "$line" ]; then
		echo "No files to Move on '$Hour' Hour"
		break
	fi
                FileName=`echo $line|awk '{print $9}'`
                #FileName="$DirName/$FileName"
                mv $FileName  $COPYPATH
                #echo "MOVE =>$FileName  $COPYPATH"
		Counter=`expr $Counter + 1`
 done

gzip -r $COPYPATH
if [ $Counter -gt 0 ]; then
	echo " Total files moved on '$Hour' Hour = $Counter"
fi

