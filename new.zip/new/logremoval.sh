#!/bin/ksh
set -x
CD=/usr/bin/cd
CAT=/usr/bin/cat
RM=/usr/bin/rm
FOLDERLIST=/wls_domains/rdwsmpd01/SCRIPTS/logarchival/archivalpaths
DAYSTORETAIN=6

for FOLDER_PATH in `${CAT} ${FOLDERLIST}`; do
if test -d ${FOLDER_PATH}; then
find ${FOLDER_PATH} -type f \( -name "*.log*" -o -name "*.gz" -o -name "*.[Cc][Ss][Vv]" -o -name ".txt" \) -mtime +${DAYSTORETAIN} -exec rm -f {} \;
fi
done
