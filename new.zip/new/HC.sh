clear
SYSDT=`date '+%b %e'`
DT=`date '+%d-%m-%Y'`
echo "WHOLESALE MPD Health Check Report generated @ `date`"

echo "---------------------Managed Server 1 [10.187.42.97]--------------------------------------"

echo "------------------------------------------------------------------------"

echo " "

INCOMING_REQ=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/RequestChannel_Incoming/$DT| grep -i "$SYSDT" | wc -l`

echo "1) Number of requests received from OneSiebel_to_MPD today = " $INCOMING_REQ

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/RequestChannel_Incoming/$DT |tail -4

echo "------------------------------------------------------------------------------"

echo " "

OUTGOING_REQ=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/MNSDRequestChannel_Outgoing/$DT | grep -i "$SYSDT"| wc -l`

echo "2) Number of requests sent from MPD_to_MNSD system today = " $OUTGOING_REQ

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/MNSDRequestChannel_Outgoing/$DT | tail -4

echo "------------------------------------------------------------------------------"

echo " "

INCOMING_RES=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/MNSDResponseChannel_Incoming/$DT | grep -i "$SYSDT"| wc -l`

echo "3) Number of responses received from MNSD_to_MPD system today = " $INCOMING_RES

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/MNSDResponseChannel_Incoming/$DT | tail -4

echo "------------------------------------------------------------------------------"

echo " "

REQ_TO_KILL_SESSION=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/KillSessionRequestChannel_Outgoing/$DT | grep -i "$SYSDT"| wc -l`

echo "4) Number of requests to Kill session of MPD_to_KillIMB = " $REQ_TO_KILL_SESSION

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/KillSessionRequestChannel_Outgoing/$DT | tail -4

echo "------------------------------------------------------------------------------"

echo " "

RES_FROM_KILL_SESSION=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/KSResponseChannel_Incoming/$DT | grep -i "$SYSDT"| wc -l`

echo "5) Number of responses received from KillIMB_to_MPD = " $RES_FROM_KILL_SESSION

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/KSResponseChannel_Incoming/$DT | tail -4

echo "------------------------------------------------------------------------------"

echo " "


OUTGOING_RES5=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/01_Outgoing/$DT | grep -i "$SYSDT"|wc -l`

echo "6) Number of responses sent from MPD_to_OneSiebel  system today = " $OUTGOING_RES5

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages1/01_Outgoing/$DT | tail -4

echo "------------------------------------------------------------------------------"


echo "---------------------Managed Server 2 [10.187.42.98]--------------------------------------"



echo "------------------------------------------------------------------------"

echo " "

INCOMING_REQ=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/RequestChannel_Incoming/$DT| grep -i "$SYSDT" | wc -l`

echo "1) Number of requests received from OneSiebel_to_MPD today = " $INCOMING_REQ

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/RequestChannel_Incoming/$DT |tail -4

echo "------------------------------------------------------------------------------"

echo " "

OUTGOING_REQ=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/MNSDRequestChannel_Outgoing/$DT | grep -i "$SYSDT"| wc -l`

echo "2) Number of requests sent from MPD_to_MNSD system today = " $OUTGOING_REQ

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/MNSDRequestChannel_Outgoing/$DT | tail -4

echo "------------------------------------------------------------------------------"

echo " "

INCOMING_RES=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/MNSDResponseChannel_Incoming/$DT | grep -i "$SYSDT"| wc -l`

echo "3) Number of responses received from MNSD_to_MPD system today = " $INCOMING_RES

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/MNSDResponseChannel_Incoming/$DT | tail -4

echo "------------------------------------------------------------------------------"

echo " "

REQ_TO_KILL_SESSION=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/KillSessionRequestChannel_Outgoing/$DT | grep -i "$SYSDT"| wc -l`

echo "4) Number of requests to Kill session of MPD_to_KillIMB = " $REQ_TO_KILL_SESSION

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/KillSessionRequestChannel_Outgoing/$DT | tail -4

echo "------------------------------------------------------------------------------"

echo " "

RES_FROM_KILL_SESSION=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/KSResponseChannel_Incoming/$DT | grep -i "$SYSDT"| wc -l`

echo "5) Number of responses received from KillIMB_to_MPD = " $RES_FROM_KILL_SESSION

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/KSResponseChannel_Incoming/$DT | tail -4

echo "------------------------------------------------------------------------------"

echo " "


OUTGOING_RES5=`ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/01_Outgoing/$DT | grep -i "$SYSDT"|wc -l`

echo "6) Number of responses sent from MPD_to_OneSiebel  system today = " $OUTGOING_RES5

echo "------------------------------------------------------------------------------"

ls -ltr /wls_domains/rdwsmpd01/logs/project/messages2/01_Outgoing/$DT | tail -4

echo "------------------------------------------------------------------------------"




echo " "

echo "================================================================================================================="

echo "ADMIN AND MANAGED SERVERS RUNNING ON 10.187.42.97"

echo "================================================================================================================="

echo "CRITICAL PARTITIONS DISK SPACE UTILIZATION"

echo "------------------------------------------"

df -kh | tail -6

echo "================================================================================================================="

echo "CPU UTILIZTION:"

echo "---------------"

sar 2 10

echo "========================================================================="

echo "SERVER STATUS"

echo "-------------"

ps -aef | grep bea

echo "================================================================================================================="

#echo "Admin Server listening Port information"

echo "LISTENING TO PORT"
echo "---------------------------------------"

netstat -a | grep -i listen | grep -i 61001

#echo "================================================================================================================="

#echo "Managed1 Server listening Port information"

#echo "---------------------------------------"

netstat -a | grep -i listen | grep -i 61000

echo
exit 0

