echo "Date : $1"
echo "Identifier : $2"

echo "*******************PAL to COP****************************"

cd /wls_domains/rdwsmpd01/logs/project/messages1/RequestChannel_Incoming/$1

for i in `grep -li $2 *.log`
do
echo "MS1:\n"
cat $i| grep "INFO" | cut -d" " -f1,2
done

cd /wls_domains/rdwsmpd01/logs/project/messages2/RequestChannel_Incoming/$1

for i in `grep -li $2 *.log`
do
echo "MS2:\n"
cat $i| grep "INFO" |cut -d" " -f1,2
done

echo

echo "*******************COP to IMB***************************"

cd /wls_domains/rdwsmpd01/logs/project/messages1/MNSDRequestChannel_Outgoing/$1

for i in `grep -li $2 *.log`
do
echo "MS1:\n"
cat $i| grep "INFO" | cut -d" " -f1,2
done

cd /wls_domains/rdwsmpd01/logs/project/messages2/MNSDRequestChannel_Outgoing/$1
for i in `grep -li $2 *.log`
do
echo "MS2:\n"
cat $i| grep "INFO" | cut -d" " -f1,2
done

echo

echo "*******************IMB to COP***************************"

cd /wls_domains/rdwsmpd01/logs/project/messages1/MNSDResponseChannel_Incoming/$1
for i in `grep -li $2 *.log`
do
echo "MS1:\n"
cat $i| grep "INFO" | cut -d" " -f1,2
done

cd /wls_domains/rdwsmpd01/logs/project/messages2/MNSDResponseChannel_Incoming/$1
for i in `grep -li $2 *.log`
do
echo "MS2:\n"
cat $i| grep "INFO" | cut -d" " -f1,2
done

echo

echo "*******************COP to PAL***************************"

cd /wls_domains/rdwsmpd01/logs/project/messages1/01_Outgoing/$1
for i in `grep -li $2 *.log`
do
echo "MS1:\n"
cat $i| grep "INFO" | cut -d" " -f1,2
done

cd /wls_domains/rdwsmpd01/logs/project/messages2/01_Outgoing/$1
for i in `grep -li $2 *.log`
do
echo "MS2:\n"
cat $i| grep "INFO" | cut -d" " -f1,2
done

echo "*******************COP to IMB(Kill Session)***************************"

cd /wls_domains/rdwsmpd01/logs/project/messages1/KillSessionRequestChannel_Outgoing/$1

for i in `grep -li $2 *.log`
do
echo "MS1:\n"
cat $i| grep "INFO" | cut -d" " -f1,2
done

cd /wls_domains/rdwsmpd01/logs/project/messages2/KillSessionRequestChannel_Outgoing/$1
for i in `grep -li $2 *.log`
do
echo "MS2:\n"
cat $i| grep "INFO" | cut -d" " -f1,2
done

echo

echo "*******************IMB to COP(Kill Session)***************************"

cd /wls_domains/rdwsmpd01/logs/project/messages1/KSResponseChannel_Incoming/$1

for i in `grep -li $2 *.log`
do
echo "MS1:\n"
cat $i| grep "INFO" | cut -d" " -f1,2
done

cd /wls_domains/rdwsmpd01/logs/project/messages2/KSResponseChannel_Incoming/$1
for i in `grep -li $2 *.log`
do
echo "MS2:\n"
cat $i| grep "INFO" | cut -d" " -f1,2
done

echo
