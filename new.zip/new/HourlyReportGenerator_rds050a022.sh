#/bin/sh
#set -x
. /wls_domains/rdwsmpd01/bt_utils_inc.sh
. /wls_domains/rdwsmpd01/bin/setDomainEnv.sh

>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
echo >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
#myperf mpdserver2_rdwsmpd01 jvm >> /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
#sleep 5
grep -i 'OutOfMemoryError' /wls_domains/rdwsmpd01/logs/bea/mpdserver2_rdwsmpd01.log >> /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
#echo "-----------------------------------------------------------------------------------">>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
#echo >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022

#MANAGED=`java weblogic.Admin -url 10.187.42.98:61000 -username weblogic -password security GETSTATE`

#echo "MANAGED=$MANAGED" >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022

DATE=`date  '+%Y%m%d'`
FILE="/wls_domains/rdwsmpd01/SCRIPTS/webmonitor/CSV_HOME/rdwsmpd01_MS2_$DATE.csv"
Thread=`tail -1 $FILE|cut -d"," -f2,3,4,5,6,8,9,10`
echo "MANAGED,$Thread">>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022


# DISK Statistics..

DISK=`df -k|grep /wls_domains/rdwsmpd01_logs|awk '{print $2/1024 , $3/1024, $4/1024,$5}'`
echo "/wls_domains/rdwsmpd01_logs $DISK" >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
DISK=`df -k|grep /wls_domains/rdwsmpd01|grep -v /wls_domains/rdwsmpd01_logs|awk '{print $2/1024 , $3/1024, $4/1024,$5}'`
echo "/wls_domains/rdwsmpd01 $DISK" >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
DISK=`df -k|grep /mqlocal|awk '{print $2/1024 , $3/1024, $4/1024,$5}'`
echo "/mqlocal $DISK" >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
DISK=`df -k|grep /mqcl_RDS502P1|awk '{print $2/1024 , $3/1024, $4/1024,$5}'`
echo "/mqcl_RDS502P1 $DISK" >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
DISK=`df -k|grep /bptm_logs |awk '{print $2/1024 , $3/1024, $4/1024,$5}'`
echo "/bptm_logs $DISK" >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022

CPU=`tail -1 /wls_domains/rdwsmpd01/SCRIPTS/cpuutil/rds050a022_mpdserver2_rdwsmpd01_WS-MPD98_CPU.csv`
echo "CPU,$CPU">>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022

#MQ=`tail -3 /wls_domains/rdwsmpd01/SCRIPTS/webmonitor/MQ-WSMPD-SiteA-MS2.txt|grep count|cut -d" " -f 2`
#echo "MQ,$MQ" >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022

java weblogic.Admin -url 10.187.42.98:61000 -username weblogic -password security GET -pretty -type JMSDestinationRuntime -property MessagesPendingCount -property ConsumersCurrentCount -property  MessagesCurrentCount >/wls_domains/rdwsmpd01/SCRIPTS/JMSout.dat
if [ $? -eq 0 ]
then
        cat /wls_domains/rdwsmpd01/SCRIPTS/JMSout.dat |while read x
        do
                MYFIELD=`echo $x | awk -F: '{print $1}'`
                if [ "$MYFIELD" = "MBeanName" ] ; then
                        SERVR_NAME=`echo $x | cut -d'=' -f2`
                        SERVR_NAME1=`echo ${SERVR_NAME} | cut -d',' -f1`
                        MYFLD2=`echo $x | cut -d'=' -f3`
                        QUEUE_NAME=`echo ${MYFLD2} | cut -d',' -f1`
                        read x
                        ConsumersCurrentCount1=`echo $x | awk -F: '{print $2}'`
                        ConsumersCurrentCount=`echo ${ConsumersCurrentCount1} | cut -d' ' -f2`
                        read x
                        MessagesCurrentCount1=`echo $x | awk -F: '{print $2}'`
                        MessagesCurrentCount=`echo ${MessagesCurrentCount1} | cut -d' ' -f2`
                        read x
                        MessagesPendingCount1=`echo $x | awk -F: '{print $2}'`
                        MessagesPendingCount=`echo ${MessagesPendingCount1} | cut -d' ' -f2`
                        echo "JMS:10.187.42.98,$QUEUE_NAME,$ConsumersCurrentCount,$MessagesCurrentCount,$MessagesPendingCount" >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
 fi
        done
fi

date=`date '+%d-%m-%Y'`
cat /wls_domains/rdwsmpd01/SCRIPTS/new/Hourly_Traffic_WS-MPD98_$date.dat |while read x
do
        echo "TRAFFICDATA#$x" >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022
done


cat /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022





mv /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a022 /wls_domains/rdwsmpd01/SCRIPTS/WSMPD-SITEA-MS2.dat

HOST='10.230.189.138'
USER='copasg'
PASSWD='test1234'

ftp -n $HOST <<END_SCRIPT
quote USER $USER
quote PASS $PASSWD
cd /export/home/situser/copasg_area/COPReports/PlatformReport/MPD
lcd /wls_domains/rdwsmpd01/SCRIPTS
prompt off
mput WSMPD-SITEA-MS2.dat
quit
prompt on
END_SCRIPT






rm /wls_domains/rdwsmpd01/SCRIPTS/WSMPD-SITEA-MS2.dat
rm /wls_domains/rdwsmpd01/SCRIPTS/JMSout.dat

