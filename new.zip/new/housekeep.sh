#!/bin/ksh
z=`date +%d`
z1=`date +%m`
z2=`date +%Y`

if test $z -eq 01
then
if test $z1 -eq 01 -o $z1 -eq 03 -o $z1 -eq 05 -o $z1 -eq 07 -o $z1 -eq 08 -o $z1 -eq 10 -o $z1 -eq 12
then
d="30-$z1-$z2"
fi
elif test $z -eq 02
then
if test $z1 -eq 01 -o $z1 -eq 03 -o $z1 -eq 05 -o $z1 -eq 07 -o $z1 -eq 08 -o $z1 -eq 10 -o $z1 -eq 12
then
d="31-$z1-$z2"
fi
elif test $z -eq 01
then
if test $z1 -eq 02 -o $z1 -eq 04 -o $z1 -eq 06 -o $z1 -eq 09 -o $z1 -eq 11
then
d="29-$z1-$z2"
fi
elif test $z -eq 02
then
if test $z1 -eq 02 -o $z1 -eq 04 -o $z1 -eq 06 -o $z1 -eq 09 -o $z1 -eq 11
then
d="30-$z1-$z2"
fi
else
z=`expr $z - 2`
if test $z -le 09
then
x=0
z="$x$z"
d="$z-$z1-$z2"
else
d="$z-$z1-$z2"
fi
fi


cd /wls_domains/rdwsmpd01_logs/project/messages/backup/RequestChannel_Incoming
mkdir $d
chmod 777 $d
find /wls_domains/rdwsmpd01_logs/project/messages/RequestChannel_Incoming/$d -name \*.log -exec mv {} /wls_domains/rdwsmpd01_logs/project/messages/backup/RequestChannel_Incoming/$d \;

cd /wls_domains/rdwsmpd01_logs/project/messages/backup/MNSDRequestChannel_Outgoing
mkdir $d
chmod 777 $d
find /wls_domains/rdwsmpd01_logs/project/messages/MNSDRequestChannel_Outgoing/$d -name \*.log -exec mv {} /wls_domains/rdwsmpd01_logs/project/messages/backup/MNSDRequestChannel_Outgoing/$d \;

cd /wls_domains/rdwsmpd01_logs/project/messages/backup/MNSDResponseChannel_Incoming
mkdir $d
chmod 777 $d
find /wls_domains/rdwsmpd01_logs/project/messages/MNSDResponseChannel_Incoming/$d -name \*.log -exec mv {} /wls_domains/rdwsmpd01_logs/project/messages/backup/MNSDResponseChannel_Incoming/$d \;

cd /wls_domains/rdwsmpd01_logs/project/messages/backup/KSResponseChannel_Incoming
mkdir $d
chmod 777 $d
find /wls_domains/rdwsmpd01_logs/project/messages/KSResponseChannel_Incoming/$d -name \*.log -exec mv {} /wls_domains/rdwsmpd01_logs/project/messages/backup/KSResponseChannel_Incoming/$d \;

cd /wls_domains/rdwsmpd01_logs/project/messages/backup/KillSessionRequestChannel_Outgoing
mkdir $d
chmod 777 $d
find /wls_domains/rdwsmpd01_logs/project/messages/KillSessionRequestChannel_Outgoing/$d -name \*.log -exec mv {} /wls_domains/rdwsmpd01_logs/project/messages/backup/KillSessionRequestChannel_Outgoing/$d \;

cd /wls_domains/rdwsmpd01_logs/project/messages/backup/01_Outgoing
mkdir $d
chmod 777 $d
find /wls_domains/rdwsmpd01_logs/project/messages/01_Outgoing/$d -name \*.log -exec mv {} /wls_domains/rdwsmpd01_logs/project/messages/backup/01_Outgoing/$d \;
