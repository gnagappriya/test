#/bin/sh
#set -x
. /wls_domains/rdwsmpd01/bt_utils_inc.sh

>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a021
echo >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a021
myperf mpdserver1_rdwsmpd01 jvm >> /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a021
sleep 5
grep -i 'OutOfMemoryError' /wls_domains/rdwsmpd01/logs/bea/mpdserver1_rdwsmpd01.log >> /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a021
echo "-----------------------------------------------------------------------------------">>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a021
echo >>/wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a021

cat /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a021
rm /wls_domains/rdwsmpd01/SCRIPTS/heap_rds050a021

