clear
#SYSDT=`date '+%h%d %T'|tr -s " " "-"`
SYSDT=`date '+%Y%m%d %T'|tr -s " " "-"`
cd /wls_domains/rdwsmpd01/SCRIPTS
subfile="MPD_WS_10_187_42_97_HEALTHREPORT_"$SYSDT
file="MPD_WS_10_187_42_97_HEALTHREPORT_"$SYSDT.txt
sh HC.sh >$file
#cat $file | mailx -s "`echo $file`"  -a "$file" dorababu.karnam@bt.com
#uuencode $file $file | mailx -s "`echo $subfile`" balamurali.jothithanikachalam@bt.com kiran.2.kumar@bt.com prasanthi.pachipulusu@bt.com surendra.raju@bt.com copasg@techmahindra.com

HOST='10.230.189.138'
USER='copasg'
PASSWD='test1234'

ftp -n $HOST <<END_SCRIPT
quote USER $USER
quote PASS $PASSWD
cd /export/home/situser/copasg_area/COPReports/HCReports/Wholesale/MPD
lcd /wls_domains/rdwsmpd01/SCRIPTS
prompt off
mput $file
quit
prompt on
END_SCRIPT

exit 0






