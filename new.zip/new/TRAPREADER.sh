#!/bin/ksh

Filename=$1
#read Filename

echo "MONITORED_OBJECT_TYPE,LOG FILE NAME,FilterName,GasID,TrapText,TrapValue,Priority,Queue,CensorTime,Check Time, Threshold"
cat $Filename |while read line
do
        if [ "$line" = "<MONITORED_OBJECT>" ]
        then
           read MONITORED_OBJECT_TYPE
           read MONITORED_ITEM
           MONITORED_OBJECT_TYPE=`echo $MONITORED_OBJECT_TYPE|cut -d"=" -f2`
           MONITORED_ITEM=`echo $MONITORED_ITEM|cut -d"=" -f2`
           while [ 1 ]; do
                read line
                if [ "$line" = "<FILTER>" ]; then
                        while [ 1 ]; do
                                read line
                                if [ "$line" = "</FILTER>" ]; then

                                        break;
                                else
                                        PATT1=`echo $line|cut -d"=" -f1`
                                        PATT=`echo $line|cut -d" " -f1`
                                        VALUE=`echo $line|cut -d"=" -f2`
                                        if [ "$PATT" = "<FILTER_NAME" ]; then
                                              FiletName=$VALUE
                                        elif [ "$PATT" = "<GASID" ]; then
                                              GaSID=$VALUE
                                        elif [ "$PATT" = "<TRAP_TEXT" ]; then
                                              TrapText=$VALUE
                                        elif [ "$PATT" = "<TRAP" ]; then
                                              TrapValue=$VALUE
                                        elif [ "$PATT" = "<BRIDGE_PRTY" ]; then
                                              Priority=$VALUE
                                        elif [ "$PATT" = "<BRIDGE_CLASS" ]; then
                                              Queue=$VALUE
                                        elif [ "$PATT" = "<CENSOR_TIME" ]; then
                                              CensorTime=$VALUE
                                        elif [ "$PATT" = "<CHECK_TIME" ]; then
                                              CheckTime=$VALUE
                                        elif [ "$PATT" = "<THRESHOLD" ]; then
                                              Threshold=$VALUE
                                        fi
                                fi
                                #echo "In FILTER Loop: $line"
                        done
                           echo "$MONITORED_OBJECT_TYPE,$MONITORED_ITEM,$FiletName,$GaSID,$TrapText,$TrapValue,$Priority,$Queue,$CensorTime,$CheckTime,$Threshold"

                elif [ "$line" = "</MONITORED_OBJECT>" ]; then
                        break
                fi
           done
        fi
done
